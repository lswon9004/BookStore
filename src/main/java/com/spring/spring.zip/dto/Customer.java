package com.spring.dto;

import lombok.Data;

@Data
public class Customer {
	int custid;
	String name;
	String address;
	String phone;
}
