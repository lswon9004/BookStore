package com.spring.dto;

import lombok.Data;

@Data
public class Book {
	private int bookid;
	private String bookname;
	private String publisher;
	private int price;
}
